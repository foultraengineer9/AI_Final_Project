import pandas as pd

# Load the dataset with POS tagging and frequency
df = pd.read_csv("words_features_with_frequency.csv")

# One-hot encode the POS column
pos_encoded = pd.get_dummies(
    df["POS"],
    prefix="POS",
    dtype=int
)

df = pd.concat([df, pos_encoded], axis = 1)

# Save the encoded dataset
df.to_csv("POS_tagged_frequency_one_hot_encoded.csv", index=False)

# Display the first 20 rows
print(df.head(20))