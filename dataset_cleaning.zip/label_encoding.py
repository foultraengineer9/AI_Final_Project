import pandas as pd

# Load CSV
df = pd.read_csv("cleaned_file.csv")

# CEFR to number mapping
cefr_mapping = {
    "A1": 1,
    "A2": 2,
    "B1": 3,
    "B2": 4,
    "C1": 5,
    "C2": 6
}

# Convert CEFR levels to numbers
df["CEFR_numeric"] = df["CEFR"].map(cefr_mapping)

# Save the result
df.to_csv("label_encoded_file.csv", index=False)

print(df.head())