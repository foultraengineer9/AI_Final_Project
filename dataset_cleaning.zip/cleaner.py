import pandas as pd

# For CSV
df = pd.read_csv("ENGLISH_CERF_WORDS.csv")

# Remove duplicates only when BOTH headword and CEFR are identical
df = df.drop_duplicates(subset=["headword", "CEFR"], keep="first")

# Save the cleaned file
df.to_csv("cleaned_file.csv", index=False)