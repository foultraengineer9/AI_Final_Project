import pandas as pd
from wordfreq import zipf_frequency

# Load your CSV
df = pd.read_csv("POS_tagged.csv")

# Calculate frequency score
df["frequency"] = df["headword"].astype(str).apply(
    lambda word: zipf_frequency(word, "en")
)

# Save
df.to_csv("words_features_with_frequency.csv", index=False)

print(df[["headword", "frequency"]].head(20))