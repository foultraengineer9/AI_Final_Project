import pandas as pd
import nltk
from nltk.corpus import wordnet

# Download WordNet
nltk.download("wordnet")

# Load your CSV
df = pd.read_csv("words_features.csv")

# Function to get POS
def get_wordnet_pos(word):
    synsets = wordnet.synsets(word)

    if not synsets:
        return "unknown"

    pos = synsets[0].pos()

    mapping = {
        "n": "noun",
        "v": "verb",
        "a": "adjective",
        "r": "adverb",
        "s": "adjective"
    }

    return mapping.get(pos, "other")

# Add POS column
df["POS"] = df["headword"].astype(str).apply(get_wordnet_pos)

# Save the updated file
df.to_csv("POS_tagged.csv", index=False)

# Display results
print(df[["headword", "POS"]].head(20))