import pandas as pd
import syllables
import nltk
from nltk import pos_tag

# Download POS tagger
nltk.download("averaged_perceptron_tagger_eng")

# Load CSV
df = pd.read_csv("words_features.csv")

# Clean word column
df["word"] = df["headword"].astype(str).str.strip()

# -------------------------
# CEFR
# -------------------------

cefr_mapping = {
    "A1": 1,
    "A2": 2,
    "B1": 3,
    "B2": 4,
    "C1": 5,
    "C2": 6
}

df["CEFR"] = df["CEFR"].str.strip().str.upper()
df["CEFR_numeric"] = df["CEFR"].map(cefr_mapping)

# -------------------------
# Word length
# -------------------------

df["word_length"] = df["headword"].str.len()

# -------------------------
# Syllable count
# -------------------------

df["syllable_count"] = df["headword"].apply(syllables.estimate)

# -------------------------
# Part of Speech
# -------------------------

def get_pos(word):
    tag = pos_tag([word])[0][1]
    return tag

df["POS"] = df["headword"].apply(get_pos)

# -------------------------
# Save
# -------------------------

df.to_csv("POS_tagged.csv", index=False)

print(df.head(20))