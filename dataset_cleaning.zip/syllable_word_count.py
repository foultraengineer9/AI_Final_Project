import pandas as pd
import syllables

# Load CSV
df = pd.read_csv("cleaned_file.csv")

# Clean CEFR values
df["CEFR"] = df["CEFR"].astype(str).str.strip().str.upper()

# Convert CEFR to numbers
cefr_mapping = {
    "A1": 1,
    "A2": 2,
    "B1": 3,
    "B2": 4,
    "C1": 5,
    "C2": 6
}

df["CEFR_numeric"] = df["CEFR"].map(cefr_mapping)

# Word length
df["word_length"] = df["headword"].astype(str).str.len()

# Syllable count
df["syllable_count"] = df["headword"].astype(str).apply(syllables.estimate)

# Save
df.to_csv("words_features.csv", index=False)

print(df.head(10))